unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, Types,
  LCLType, ExtCtrls, ComCtrls, DefaultTranslator;

type

  { TMainForm }

  TMainForm = class(TForm)
    GroupBox1: TGroupBox;
    ImageList1: TImageList;
    ListBox1: TListBox;
    ProgressBar1: TProgressBar;
    StaticText1: TStaticText;
    procedure FormShow(Sender: TObject);
    procedure ListBox1DblClick(Sender: TObject);
    procedure ListBox1DrawItem(Control: TWinControl; Index: integer;
      ARect: TRect; State: TOwnerDrawState);
  private

  public

  end;

resourcestring
  SRunStartAsRoot = 'Run the program using StartAsRoot!';
  SPapirusNotInstalled = 'The "Papirus" icon theme is not installed!';
  SChangeTheColor = 'Change the color of directory icons?';
  SProcessing = 'Processing:';

var
  MainForm: TMainForm;

implementation

uses starttrd;

  {$R *.lfm}

  { TMainForm }

procedure TMainForm.ListBox1DrawItem(Control: TWinControl; Index: integer;
  ARect: TRect; State: TOwnerDrawState);
var
  ListBox: TListBox;
  ImgIndexStart: integer;
  CurrentLeft: integer;
  ImgWidth: integer;
  I: integer;
  TextOffset: integer;
begin
  ListBox := Control as TListBox;

  // 1. Очищаем фон (рисуем стандартный фон выделенного или обычного пункта)
  ListBox.Canvas.FillRect(ARect);

  // Проверяем, привязан ли ImageList и есть ли элементы
  if Assigned(ImageList1) and (Index >= 0) then
  begin
    ImgWidth := ImageList1.Width;

    // Вычисляем начальный индекс картинки для текущей строки.
    // Для строки 0: 0,1,2; для строки 1: 3,4,5 и так далее.
    ImgIndexStart := Index * 3;

    // Начальная координата X для первой картинки (с отступом в 4 пикселя слева)
    CurrentLeft := ARect.Left + 4;

    // 2. Рисуем 3 картинки подряд
    for I := 0 to 2 do
    begin
      // Проверяем, что такой индекс вообще существует в ImageList
      if (ImgIndexStart + I) < ImageList1.Count then
      begin
        // Рисуем картинку по центру текущей строки по вертикали
        ImageList1.Draw(
          ListBox.Canvas,
          CurrentLeft,
          ARect.Top + (ARect.Height - ImageList1.Height) div 2,
          ImgIndexStart + I
          );
        // Сдвигаем позицию для следующей картинки (+ небольшое расстояние между ними)
        CurrentLeft := CurrentLeft + ImgWidth + 2;
      end;
    end;

    // 3. Вычисляем отступ для текста, чтобы он не накладывался на картинки
    TextOffset := CurrentLeft + 6;
  end;

  // 4. Рисуем сам текст строки
  // Выравниваем текст по вертикали внутри выделенной области
  ListBox.Canvas.TextRect(
    ARect,
    TextOffset,
    ARect.Top + (ARect.Height - ListBox.Canvas.TextHeight(ListBox.Items[Index])) div 2,
    ListBox.Items[Index]
    );
end;

procedure TMainForm.FormShow(Sender: TObject);
begin
  ListBox1.ItemIndex := 0;
end;

procedure TMainForm.ListBox1DblClick(Sender: TObject);
begin
  if GetEnvironmentVariable('USER') <> 'root' then
  begin
    MessageDlg(SRunStartAsRoot, mtWarning, [mbOK], 0);
    Application.Terminate;
    Exit;
  end;

  //Основной каталог темы
  if not DirectoryExists('/usr/share/icons/Papirus') then
  begin
    MessageDlg(SPapirusNotInstalled, mtWarning, [mbOK], 0);
    Exit;
  end;

  if MessageDlg(SChangeTheColor, mtConfirmation, [mbYes, mbNo], 0) = mrYes then
    TStartInstallTheme.Create;
end;

end.
