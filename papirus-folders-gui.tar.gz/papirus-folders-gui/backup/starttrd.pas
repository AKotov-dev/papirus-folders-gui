unit starttrd;


{$mode objfpc}{$H+}

interface

uses
  Classes, Process, SysUtils, Forms, Controls, ComCtrls;

type
  TStartInstallTheme = class(TThread)
  private
    FThemeName: string;

  protected
    procedure Execute; override;
    procedure ShowProgress;
    procedure Papirus;
    procedure PapirusDark;
    procedure PapirusLight;
    procedure HideProgress;
  public
    constructor Create;
    destructor Destroy; override;

  end;

implementation

uses Unit1;

  { TRD }

constructor TStartInstallTheme.Create;
begin
  inherited Create(False); // запускаем поток сразу
  FreeOnTerminate := True; // освобождение автоматически
  FThemeName := MainForm.ListBox1.Items[MainForm.ListBox1.ItemIndex];
end;

destructor TStartInstallTheme.Destroy;
begin
  inherited Destroy;
end;

//Запуск установки
procedure TStartInstallTheme.Execute;
var
  p: string;
  ExProcess: TProcess;
begin
  //Путь до papirus-folders
  p := '"' + ExtractFilePath(ParamStr(0)) + 'papirus-folders"';

  try
    Synchronize(@ShowProgress);

    //Рабочий процесс
    ExProcess := TProcess.Create(nil);

    ExProcess.Executable := 'bash';
    ExProcess.Options := [poWaitOnExit];

    //Команда papirus-folders -t "Papirus" -C "тема"

    if DirectoryExists('/usr/share/icons/Papirus') and not Terminated then
    begin
      Synchronize(@Papirus);
      ExProcess.Parameters.Clear;
      ExProcess.Parameters.Add('-c');
      ExProcess.Parameters.Add(p + ' -t "Papirus" -C "' + FThemeName + '"');
      Exprocess.Execute;
    end;

    if (DirectoryExists('/usr/share/icons/Papirus-Dark')) and not Terminated then
    begin
      Synchronize(@PapirusDark);
      ExProcess.Parameters.Clear;
      ExProcess.Parameters.Add('-c');
      ExProcess.Parameters.Add(p + ' -t "Papirus-Dark" -C "' + FThemeName + '"');
      Exprocess.Execute;
    end;

    if DirectoryExists('/usr/share/icons/Papirus-Light') and not Terminated then
    begin
      Synchronize(@PapirusLight);
      ExProcess.Parameters.Add('-c');
      ExProcess.Parameters.Add(p + ' -t "Papirus-Light" -C "' + FThemeName + '"');
      Exprocess.Execute;
    end;

  finally
    Synchronize(@HideProgress);
    ExProcess.Free;
  end;
end;

//Запустить индикатор
procedure TStartInstallTheme.ShowProgress;
begin
  with MainForm do
  begin
    ListBox1.Enabled := False;
    GroupBox1.Visible := True;
    ProgressBar1.Style := pbstMarquee;
  end;
end;

procedure TStartInstallTheme.Papirus;
begin
  MainForm.GroupBox1.Caption := SProcessing + ' Papirus';
end;

procedure TStartInstallTheme.PapirusDark;
begin
  MainForm.GroupBox1.Caption := SProcessing + ' Papirus-Dark';
end;

procedure TStartInstallTheme.PapirusLight;
begin
  MainForm.GroupBox1.Caption := SProcessing + ' Papirus-Light';
end;

//Остановить индикатор
procedure TStartInstallTheme.HideProgress;
begin
  with MainForm do
  begin
    ListBox1.Enabled := True;
    GroupBox1.Visible := False;
    ProgressBar1.Style := pbstNormal;
  end;
end;

end.
